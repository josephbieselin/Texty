<?php 
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>User Verification</title>
</head>
<body>

<?php
	
	// Set up variables
	$_SESSION['username'] = $_POST['username'];
	$un = strtolower($_SESSION['username']);
	$password = $_POST['password'];

	chdir("/var/www/html/files");
	if(!file_exists("all_users.txt")) {
		echo "We currently have no users. Why don't you <a href='register.html'>register</a> and become one?";
		die();
	}


	$all_users_file = fopen("all_users.txt", "r");

	while($line = fgets($all_users_file)) {
		$test_user_data = explode(",", $line, 5);
		// Test to see if the inputted username and password match any of the users already in the system
		if(($test_user_data[0] == $un) and ($test_user_data[3] == $password)) {
			// Found a match so we direct the user to their homepage
			$_SESSION['user_index'] = $test_user_data[2]; // Store user's index for access to user's directory on homepage
			fclose($all_users_file);
			echo "<script type=\"text/javascript\">window.location = \"http://localhost/user_page.php\";</script>";
		}
	}

	fclose($all_users_file);

	// No match was found for inputted data.
	// Notify user that username or password was incorrect and they must try to log in again.
	echo "<script type=\"text/javascript\">alert('Username or Password were incorrect. Please try signing in again.'); window.location = \"http://localhost/index.php\";</script>";

?>

</body>
</html>