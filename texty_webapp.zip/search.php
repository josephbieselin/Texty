<!-- JOSEPH BIESELIN - Texty Web App -->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>search texty</title>
</head>
<body>

	<h3>
		<!-- Link back to user's homepage -->
		<p><a href="user_page.php">Home</a></p>
	</h3>

	<?php
		// Set variables to the values in the global SESSION variable if possible
		if(isset($_SESSION['user_index'])) {
			$user_index = $_SESSION['user_index'];
		}
		// If we don't know who is current logged in, die.
		else { die("Please log back in."); }

		if(isset($_SESSION['username'])) {
			$username = strtolower($_SESSION['username']);
		}
		// If we don't know who is currently logged in, die.
		else { die("Please log back in."); }

		if(isset($_GET['search_term'])) {
			$search_term = strtolower($_GET['search_term']);
		}
		// If we don't know what to search, die.
		else { die("Please try search again."); }

		// Get the contents of the file in an array
		chdir("/var/www/html/files");
		$file_array = file("all_users.txt");
		$array_size = count($file_array);
		$i = 1; /* start at 1 because first line of the file is a number, not user info */
		while($i < $array_size) {
			$line = strtolower($file_array[$i]);
			// $user_data_array contains in each position respectivly: 0 - username, 1 - email, 2 - index, 3- password, 4 - first name, 5 - last name
			// Our search will take the search term and look for it in the username, email, first name, and last name fields
			$user_data_array = explode(",", $line);
			if($user_data_array[2] != $user_index) {
				// stripos returns false if the second parameter string does not occur in the first parameter string
				if( (stripos($user_data_array[0], $search_term) !== false) or (stripos($user_data_array[1], $search_term) !== false) or (stripos($user_data_array[4], $search_term) !== false) or (stripos($user_data_array[5], $search_term) !== false) ) {
					// A match was found in the username, email, or first/last name so create a link to that user's page
					// link_to_user_page takes in the user's data except for the password
					link_to_user_page($user_data_array[0], $user_data_array[1], $user_data_array[2], $user_data_array[4], $user_data_array[5]);
				}
			}
			unset($user_data_array);
			$i++;
		}
	?>

	<!-- Functions for PHP -->
	<?php
		// link_to_user_page takes in a user's data and displays a link to their page
		function link_to_user_page($link_username, $link_email, $link_index, $link_firstname, $link_lastname) {
			echo "<a href='other_user.php?index=$link_index&username=$link_username'>$link_username</a> | Email: <b>$link_email</b> | Name: <b>$link_firstname $link_lastname</b><br/>";
		}
	?>

</body>
</html>
