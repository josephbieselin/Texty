<!-- JOSEPH BIESELIN - Texty Web App -->
<?php
	session_start();

	// Set variables to the values in the global SESSION variable if possible
	if(isset($_SESSION['user_index'])) {
		$user_index = $_SESSION['user_index'];
	}
	// If we don't know who is current logged in, die.
	else { die("Please log back in."); }

	if(isset($_SESSION['username'])) {
		$username = strtolower($_SESSION['username']);
	}
	// If we don't know who is currently logged in, die.
	else { die("Please log back in."); }

	if(isset($_GET['index'])) {
		$other_user_index = $_GET['index'];
	}
	// If we can't get the other user's index, die.
	else { die("Couldn't retrieve desired user's data."); }

	// If user and other_user's index values are the same, go to the homepage
	if($user_index == $other_user_index) {
		header("Location: user_page.php");
	}

	if(isset($_GET['username'])) {
		$other_username = strtolower($_GET['username']);
	}
	// If we don't know who the other user is, die.
	else { die("Couldn't retrieve desired user's data."); }

	// Check to see if a follow/unfollow request was submitted
	if(isset($_POST['fol_unfol'])) {
		// If there was a request to follow/unfollow, submit that request passing in both user indexes and value follow/unfollow
		submit_fol_unfol($user_index, $username, $other_user_index, $other_username, $_POST['fol_unfol']);
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>texty</title>
</head>
<body>

	<h3>
		<!-- Link back to user's homepage -->
		<a href="user_page.php">Home</a>
	</h3>
	<p>
		<!-- Search Form -->
		<form action="search.php" style="display:inline; float:left">
			<input type="text" name="search_term" placeholder="Search for users">
			<input type="submit" value="Search"> <!-- style="visibility: hidden" -->
		</form>
		<a href="index.php" style="float: right">Logout</a>
	</p>
	<div style="clear: both"></div>

	<hr/>

	<!--
	Determine if the other user we are looking at is someone that the logged in user follows.
	If we follow them, provide an "Unfollow" button.
	If we don't follow them, provide a "Follow" button. -->
 	<?php
 		// Open the followees.txt file to search for the other user's page we are on.
 		$user_dir = "/var/www/html/files/" . $user_index;
 		chdir($user_dir);
 		$user_followee_file = fopen("followees.txt", "r");
 		$cond = FALSE; /* will change to TRUE if the logged in user follows this other user */
 		// Loop through lines of the followee's file to see if we follow this other user or not
 		while($line = fgets($user_followee_file)) {
 			// $other_user_data will be an array: position 0 = other user's index, position 1 = other user's username
 			$other_user_data = explode(",", $line);
 			if($other_user_data[0] == $other_user_index) {
 				// We do follow this other user already
 				$cond = TRUE;
 				break;
 			}
 		}
 		fclose($user_followee_file);

		echo "<h2><p style='font-family:Lucida Console, Monaco, monospace; display: inline'>{$other_username}'s Stuff";
		// Unfollow buttom
		if($cond) {
			echo "<form method='post' action='other_user.php?index=$other_user_index&username=$other_username' style='display: inline'>";
			echo "<input type='text' value='unfollow' name='fol_unfol' style='visibility: hidden'>";
			echo "<input type='submit' value='Unfollow'></form>";
		}
		// Follow button
		else {
			echo "<form method='post' action='other_user.php?index=$other_user_index&username=$other_username' style='display: inline'>";
			echo "<input type='text' value='follow' name='fol_unfol' style='visibility: hidden'>";
			echo "<input type='submit' value='Follow' style='display: inline'></form>";
		}
		echo "</p></h2>";

	?>



	<!-- User data: Followees, Texty-s, Followers -->
	<table width="100%">
		<tr>
			<!-- padding: top right bottom left; -->
			<th align="left" width="28%" style="padding: 1px 2px 3px 1px">Following</th>
			<th align="center" width="44%" style="padding: 3px 2px 3px 2px">Past Messages</th>
			<th align="right" width="28%" style="padding: 1px 1px 3px 2px">Followers</th>
		</tr>
	
		<!-- Sample Table Data Contents -->
		<!-- 			<tr>
						<td align="left" width="28%" style="padding: 1px 2px 3px 1px"><a href="other_user.php">FOLLOWED PERSON</a><br/><textarea>texty</textarea></td>
						<td align="center" width="44%" style="padding: 3px 2px 3px 2px">
							<?php
							//	echo "<textarea rows=\"2\" cols=\"60\" disabled=\"disabled\">texty</textarea>";
							?>
						</td>
						<td align="right" width="28%" style="padding: 1px 1px 3px 2px"><a href="other_user.php">FOLLOWER</a></td>
					</tr>
		 -->


		<?php
			
			// Change directory to the other user's directory with personal file data
			$user_dir = "/var/www/html/files/" . $other_user_index;
			chdir($user_dir);

			// Pass the contents of the 3 users files into an array and set an index that will loop through this array and call functions as necessary
			$i = 0;
			$followees_file_array = file("followees.txt");
			$followees_size = count($followees_file_array);
			$j = 0;
			$texts_file_array = file("texts.txt");
			$texts_size = count($texts_file_array);
			$k = 0;
			$followers_file_array = file("followers.txt");
			$followers_size = count($followers_file_array);

			// Loop through the arrays of the file content
			// If we reach the end of the array or the line was empty, print empty table data
			// If there is info to display, call the function that will display the info
			while( ($i < $followees_size) or ($j < $texts_size) or ($k < $followers_size) ) {
				echo "<tr>";
				if($i >= $followees_size) {
					blank_table_data("left", "28", "2", "2", "2", "1");
				}
				elseif($followees_file_array[$i] == "") {
					blank_table_data("left", "28", "2", "2", "2", "1");
				}
				else {
					// $followees_data will contain two values: position 0 = followee's index, position 1 = followee's username
					$followees_data = explode(",", $followees_file_array[$i]);
					echo "<td align='left' width='28%' style='padding: 2px 2px 2px 1px'>";
					other_user_table_data($followees_data[0], $followees_data[1], TRUE, "middle");
					echo "</td>";
				}

				if($j >= $texts_size) {
					blank_table_data("center", "44", "2", "2", "2", "2");
				}
				elseif($texts_file_array[$j] == "") {
					blank_table_data("center", "44", "2", "2", "2", "2");
				}
				else {
					echo "<td align='center' width='44%' style='padding: 2px 2px 2px 2px'>";
					texty_table_data($texts_file_array[$j], 2, 60);
					echo "</td>";
				}
				
				if($k >= $followers_size) {
					blank_table_data("right", "28", "2", "2", "2", "1");
				}
				elseif($followers_file_array[$k] == "") {
					blank_table_data("right", "28", "2", "2", "2", "1");
				}
				else {
					// $followers_data will contain two values: position 0 = follower's index, position 1 = follower's username
					$followers_data = explode(",", $followers_file_array[$i]);
					echo "<td align='right' width='28%' style='padding: 2px 1px 2px 2px'>";
					other_user_table_data($followers_data[0], $followers_data[1], FALSE, "top");
					echo "</td>";
				}
				echo "</tr>";
				$i++; $j++; $k++;				
			}
		?>

	</table>

	<hr/>

	<p>
		<a href="deactivate.html" align="left"><u>Deactivate Account</u></a>
	</p>
	<br/>

	<!-- Texty's hidden egg -->
	<p align="center"><a href="origin.html" style="font-size:70px; color: rgb(175, 50, 111)"><b>Texty</b>: The Origin</a></p>


	<!-- PHP Functions -->
	<?php

		// other_user_table_data takes in the index and username of someone that is not the logged in user along with a boolean.
		// It will display a link to another php file that will generate the other user's info in the same format as the homepage without the option to submit a texty.
		// If $cond is true, that means the logged in user follows this person so will display their most recent texty under their link.
		function other_user_table_data($index, $username, $cond) {
			// Display a link to view the other user's page
			echo "<a href='other_user.php?index={$index}&username={$username}'>{$username}</a>";
			// If $cond is true, we will also want to display their recent texty since we follow them.
			if($cond) {
				echo "<br/>"; /* line break so texty is below the other user's username link */
				// Go to the other user's file directory to retrieve the first line of their texty file.
				$other_user_dir = "/var/www/html/files/" . $index;
				chdir($other_user_dir);
				$other_user_texty_file = fopen("texts.txt", "r");
				// If there's no texty's to read, then don't display anything...
				if($line = fgets($other_user_texty_file)) {
					texty_table_data($line, 4, 30);
				}
				fclose($other_user_texty_file);
			}

		}

		// texty_table_data takes a line from someone's texts.txt file and displays it with a passed in row and column size
		function texty_table_data($texty_line, $row_size, $col_size) {
			echo "<textarea rows='{$row_size}' cols='{$col_size}' disabled='disabled'>{$texty_line}</textarea>";
		}

		// blank_table_data takes in an alignment of left, center, or right along with a percentage of how much page width it will occupy
		// It also takes the top, right, bottom, and left padding values to surround this table data with
		function blank_table_data($alignment, $width_percent, $top, $right, $bottom, $left) {
			echo "<td align='{$alignment}' width='{$width_percent}%' style='padding: {$top}px {$right}px {$bottom}px {$left}px'></td>";
		}

		// If $fol_unfol is "follow": go to user's followee file and add other user & go to other user's follower file and add user
		// If $fol_unfol is "unfollow": go to user's followee file and remove other user & go to other user's follower file and remove user
		function submit_fol_unfol($user_index, $username, $other_user_index, $other_username, $fol_unfol) {
			$user_file = "/var/www/html/files/" . $user_index . "/followees.txt";			
			$other_user_file = "/var/www/html/files/" . $other_user_index . "/followers.txt";
			if($fol_unfol == "follow") {
				add_follow_data($user_index, $username, $other_user_index, $other_username, $user_file, $other_user_file);
			}
			else {
				remove_follow_data($user_index, $username, $other_user_index, $other_username, $user_file, $other_user_file);
			}
		}

		// Adds logged in user's info to other user's follower file & other user's info to logged in user's followee file
		function add_follow_data($user_index, $username, $other_user_index, $other_username, $user_file, $other_user_file) {
			// Set up data that will be written into both users' files
			$user_info = $user_index . "," . $username . PHP_EOL;
			$other_user_info = $other_user_index . "," . $other_username . PHP_EOL;

			// Add other user to the beginning of the followees.txt file of the logged in user
			$user_file_array = file($user_file);
			array_unshift($user_file_array, $other_user_info);
			$user_file_string = implode($user_file_array);

			// Add user to the beginning of the followers.txt file of the other user
			$other_user_file_array = file($other_user_file);
			array_unshift($other_user_file_array, $user_info);
			$other_user_file_string = implode($other_user_file_array);	

			// Put other user's info into user's followee file
			$user_file_handle = fopen($user_file, "w+");
			fwrite($user_file_handle, $user_file_string);
			fclose($user_file_handle);

			// Put user's info into other user's follower file
			$other_user_file_handle = fopen($other_user_file, "w+");
			fwrite($other_user_file_handle, $other_user_file_string);
			fclose($other_user_file_handle);
		}

		// Removes logged in user's info from other user's follower file & other user's info from logged in user's followee file
		function remove_follow_data($user_index, $username, $other_user_index, $other_username, $user_file, $other_user_file) {
			// Remove user from other user's followers file
			$other_user_file_array = file($other_user_file);
			remove_user($user_index, $other_user_file_array, $other_user_file);

			// Remove other user from user's followees file
			$user_file_array = file($user_file);
			remove_user($other_user_index, $user_file_array, $user_file);
		}

		// Removes the line where user_index is located inside of the file of filepath
		function remove_user($user_index, $file_array, $filepath) {
			$i = 0;
			while($line = $file_array[$i]) {
				// $user_array: position 0 = some user's index, position = some user's username
				$user_array = explode(",", $line);
				if( $user_array[0] == $user_index) {
					// If we have found the lilne where the user is located, remove user from the file
					unset($file_array[$i]); /* remove current array position where user was located */
					$file = fopen($filepath, "w+"); /* truncate file and write into it without user */
					$file_string = implode($file_array); /* join array back into string */
					fwrite($file, $file_string); /* write string back into file, now with user gone */
					fclose($file);
					break;
				}
			}
		}

		
	?>
	<!-- END of PHP Functions -->


</body>
</html>
