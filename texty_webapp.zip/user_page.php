<!-- JOSEPH BIESELIN - Texty Web App -->
<?php
	session_start();

	// Set variables to the values in the global SESSION variable if possible, else die.
	if(isset($_SESSION['username'])) {
		$username = $_SESSION['username'];
	}
	// If we don't know the username, die
	else { die("Please log back in."); }

	if(isset($_SESSION['user_index'])) {
		$user_index = $_SESSION['user_index'];
	}
	// If we don't know the user's index, die.
	else { die("Please log back in."); }

	// If the form to submit a message was just sent, input that data to the necessary file with the message_to_file function
	if(isset($_POST['message'])) { message_to_file($user_index, $_POST['message']); }
?>

<!DOCTYPE html>
<html>
<head>
	<title>texty</title>
</head>
<body>

	<p>
		<!-- Search Form -->
		<form action="search.php" style="display:inline; float:left">
			<input type="text" name="search_term" placeholder="Search for users">
			<input type="submit" value="Search">   <!-- style="visibility: hidden" -->
		</form>
		<a href="index.php" style="float: right">Logout</a>
	</p>
	<div style="clear: both"></div>

	<hr/>

	<!-- JavaScript to check for newlines in texty messages -->
	<script type="text/javascript">
		function check_text() {
			var message = document.getElementById("message").value;
			if(message.indexOf("\n") != -1) {
				alert("Sorry, but no new lines are permitted in texty messages.");
				return false;
			}
			return true;
		}
	</script>

	<!-- Texty data entry which has been limited to 100 characters -->
	<form onsubmit="return check_text()" method="post" action="user_page.php" >
		<fieldset>
			<textarea rows="2" cols="60" style="display:inline" name="message" id="message" maxlength="100" placeholder="Don't forget about the 100 character limit..." required></textarea>
			<input type="submit" value="Share Brain Thoughts" style="display:inline; vertical-align:top">
			<br/>
		</fieldset>
	</form>

	<!-- Display the username of the page we are on -->
	<?php
		echo "<br/><h2 style=\"font-family:Lucida Console, Monaco, monospace\">{$username}'s Stuff</h2><br/>";
	?>

	<!-- User data: Followees, Texty-s, Followers -->
	<table width="100%">
		<tr>
			<!-- padding: top right bottom left; -->
			<th align="left" width="28%" style="padding: 1px 2px 3px 1px">Following</th>
			<th align="center" width="44%" style="padding: 3px 2px 3px 2px">Past Messages</th>
			<th align="right" width="28%" style="padding: 1px 1px 3px 2px">Followers</th>
		</tr>
		
		<!-- Sample Table Data Contents -->
		<!-- 			<tr>
						<td align="left" width="28%" style="padding: 1px 2px 3px 1px"><a href="other_user.php">FOLLOWED PERSON</a><br/><textarea>texty</textarea></td>
						<td align="center" width="44%" style="padding: 3px 2px 3px 2px">
							<?php
							//	echo "<textarea rows=\"2\" cols=\"60\" disabled=\"disabled\">texty</textarea>";
							?>
						</td>
						<td align="right" width="28%" style="padding: 1px 1px 3px 2px"><a href="other_user.php">FOLLOWER</a></td>
					</tr>
		 -->


		<?php
			
			// Change directory to the user's directory with personal file data
			$user_dir = "/var/www/html/files/" . $user_index;
			chdir($user_dir);

			// Pass the contents of the 3 users files into an array and set an index that will loop through this array and call functions as necessary
			$i = 0;
			$followees_file_array = file("followees.txt");
			$followees_size = count($followees_file_array);
			$j = 0;
			$texts_file_array = file("texts.txt");
			$texts_size = count($texts_file_array);
			$k = 0;
			$followers_file_array = file("followers.txt");
			$followers_size = count($followers_file_array);

			// Loop through the arrays of the file content
			// If we reach the end of the array or the line was empty, print empty table data
			// If there is info to display, call the function that will display the info
			while( ($i < $followees_size) or ($j < $texts_size) or ($k < $followers_size) ) {
				echo "<tr>";
				if($i >= $followees_size) {
					blank_table_data("left", "28", "2", "2", "2", "1");
				}
				elseif($followees_file_array[$i] == "") {
					blank_table_data("left", "28", "2", "2", "2", "1");
				}
				else {
					// $followees_data will contain two values: position 0 = followee's index, position 1 = followee's username
					$followees_data = explode(",", $followees_file_array[$i]);
					echo "<td align='left' width='28%' style='padding: 2px 2px 2px 1px'>";
					other_user_table_data($followees_data[0], $followees_data[1], TRUE, "middle");
					echo "</td>";
				}

				if($j >= $texts_size) {
					blank_table_data("center", "44", "2", "2", "2", "2");
				}
				elseif($texts_file_array[$j] == "") {
					blank_table_data("center", "44", "2", "2", "2", "2");
				}
				else {
					echo "<td align='center' width='44%' style='padding: 2px 2px 2px 2px'>";
					texty_table_data($texts_file_array[$j], 2, 60);
					echo "</td>";
				}
				
				if($k >= $followers_size) {
					blank_table_data("right", "28", "2", "2", "2", "1");
				}
				elseif($followers_file_array[$k] == "") {
					blank_table_data("right", "28", "2", "2", "2", "1");
				}
				else {
					// $followers_data will contain two values: position 0 = follower's index, position 1 = follower's username
					$followers_data = explode(",", $followers_file_array[$i]);
					echo "<td align='right' width='28%' style='padding: 2px 1px 2px 2px'>";
					other_user_table_data($followers_data[0], $followers_data[1], FALSE, "top");
					echo "</td>";
				}
				echo "</tr>";
				$i++; $j++; $k++;				
			}

		?>

	</table>

	<hr/>

	<p>
		<a href="deactivate.html" align="left"><u>Deactivate Account</u></a>
	</p>
	<br/>

	<!-- Texty's hidden egg -->
	<p align="center"><a href="origin.html" style="font-size:70px; color: rgb(175, 50, 111)"><b>Texty</b>: The Origin</a></p>


	<!-- PHP Functions -->
	<?php

		// Takes the current user's index and the texty just submitted and inputs the message into the user's texts.txt file on the first line.
		// This pushes all other texty-s down one line so the newest texty is on top.
		function message_to_file($index, $texty_message) {
			$user_dir = "/var/www/html/files/" . $index;
			chdir($user_dir);
			// Put file contents into an array
			$file_array = file("texts.txt");
			$texty_message = $texty_message . PHP_EOL;
			// Place $texty_message as the first element of the array
			array_unshift($file_array, $texty_message);
			// Turn the array back into a string and write it all the truncated file
			$texty_file = fopen("texts.txt", "w+");
			$file_string = implode($file_array);
			fwrite($texty_file, $file_string);
			fclose($texty_file);
		}

		// other_user_table_data takes in the index and username of someone that is not the logged in user along with a boolean.
		// It will display a link to another php file that will generate the other user's info in the same format as the homepage without the option to submit a texty.
		// If $cond is true, that means the logged in user follows this person so will display their most recent texty under their link.
		function other_user_table_data($index, $username, $cond, $vert_align) {
			// Display a link to view the other user's page
			echo "<a href='other_user.php?index={$index}&username={$username}' style='vertical-align: {$vert_align}'>{$username}</a>";
			// If $cond is true, we will also want to display their recent texty since we follow them.
			if($cond) {
				echo "<br/>"; /* line break so texty is below the other user's username link */
				// Go to the other user's file directory to retrieve the first line of their texty file.
				$other_user_dir = "/var/www/html/files/" . $index;
				chdir($other_user_dir);
				$other_user_texty_file = fopen("texts.txt", "r");
				// If there's no texty's to read, then don't display anything...
				if($line = fgets($other_user_texty_file)) {
					texty_table_data($line, 3, 40);
					// echo "<textarea rows='3' cols='40' disabled='disabled'>$line</textarea>";
				}
				fclose($other_user_texty_file);
			}

		}

		// texty_table_data takes a line from someone's texts.txt file and displays it with a passed in row and column size
		function texty_table_data($texty_line, $row_size, $col_size) {
			echo "<textarea rows='{$row_size}' cols='{$col_size}' disabled='disabled'>{$texty_line}</textarea>";
		}

		// blank_table_data takes in an alignment of left, center, or right along with a percentage of how much page width it will occupy
		// It also takes the top, right, bottom, and left padding values to surround this table data with
		function blank_table_data($alignment, $width_percent, $top, $right, $bottom, $left) {
			echo "<td align='{$alignment}' width='{$width_percent}%' style='padding: {$top}px {$right}px {$bottom}px {$left}px'></td>";
		}

	?>
	<!-- END of PHP Functions -->


</body>
</html>
