<!-- JOSEPH BIESELIN - Texty Web App -->
<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>texty registration submission</title>
</head>
<body>

	<?php
		/*	Create all session variables to be saved
			Session variables used in case passwords are entered wrong, the registry form will be filled out with user info supplied here */
		$fn = $_SESSION['firstname'] = $_POST['firstname'];
		$ln = $_SESSION['lastname'] = $_POST['lastname'];
		$_SESSION['email'] = $_POST['email'];
		$email = strtolower($_SESSION['email']);
		$_SESSION['username'] = $_POST['username'];
		$un = strtolower($_SESSION['username']);
		$pw = $_SESSION['password'] = $_POST['password'];
		$pw_c = $_SESSION['password_check'] = $_POST['password_check'];
	?>

	<h1>You're officially a texty-er!</h1>

	<?php
		// Entering User Data into master text file

		// Accessing the directory "files" (creating it if it didn't already exists) and then opening "all_users.txt" to input a new user into the file
		if(!is_dir("/var/www/html/files")) {
			/* make a directory for all files and give anyone full access to it */
			mkdir("/var/www/html/files");
			chmod("/var/www/html/files", 0777);
		}
		chdir("/var/www/html/files"); /* Change directory to get access to text files */
		if(!file_exists("all_users.txt")) {
			$user_file = fopen("all_users.txt", "w+") or die("DEAD");
			$starter_data = "1" . PHP_EOL;
			fwrite($user_file, $starter_data);
			fseek($user_file, 0);
		}
		else {
			$user_file = fopen("all_users.txt", "r+") or die("Couldn't add you to the system. Please try registering again.");
		}

		// Get the current index value stored in the file
		$current_index;
		while(($char = fgetc($user_file)) != PHP_EOL ) {
			$current_index = "$current_index$char";
		}

		// Check to make sure username/email isn't taken
		while($line = fgets($user_file)) {
			//list($test_un, $test_email, $garbage) = explode(",", $line, 3); /* splits comma delimited line into a username, email, and a string of data that is not needed for testing */
			$test_arr = explode(",", $line, 3);
			if( ($test_arr[0] == $un) and ($test_arr[1] == $email) ) {
				// The following executes JavaScript code to alert the user that an error has occured and they must retry registering.
				// The user will then be redirected back to the register.html page
				fclose($user_file); /* Close the file since an error has occured */
				echo "<script type=\"text/javascript\">alert('Username and Email are already used in our system. Please retry registration with a different username and email.'); window.location = \"http://localhost/register.html\";</script>";
				exit();
			}
			elseif($test_arr[0] == $un) {
				// The following executes JavaScript code to alert the user that an error has occured and they must retry registering.
				// The user will then be redirected back to the register.html page
				fclose($user_file); /* Close the file since an error has occured */
				echo "<script type=\"text/javascript\">alert('Username is already being used in our system. Please retry registration with a different username.'); window.location = \"http://localhost/register.html\";</script>";
				exit();
			}
			elseif($test_arr[1] == $email) {
				// The following executes JavaScript code to alert the user that an error has occured and they must retry registering.
				// The user will then be redirected back to the register.html page
				fclose($user_file); /* Close the file since an error has occured */
				echo "<script type=\"text/javascript\">alert('Email is already being used in our system. Please retry registration with a different email.'); window.location = \"http://localhost/register.html\";</script>";
				exit();
			}
		}
		// Username and Email are not already taken. Add new user to the system
		// Enter User Data into all_users.txt file, and since we just looped through entire file for checking, data will be entered at the end of the file
		$user_data = "$un,$email,$current_index,$pw,$fn,$ln" . PHP_EOL;
		fwrite($user_file, $user_data);

		fseek($user_file, 0); /* go back to beginning of file to update index */
		$next_index = $current_index + 1;
		$next_index = "$next_index" . PHP_EOL;
		fwrite($user_file, $next_index); /* update index for when next user registers */
		
		// Close file
		fclose($user_file);

		// Create new directory for user
		$user_dir = "/var/www/html/files/" . $current_index; /* user directory referenced by the index number */
		mkdir($user_dir);
		chdir($user_dir);

		// Create files to hold user's texty-s, followers, and followees
		$file = fopen("texts.txt", "w"); fclose($file);
		$file = fopen("followers.txt", "w"); fclose($file);
		$file = fopen("followees.txt", "w"); fclose($file);


		// Change working directory back to html
		chdir("/var/www/html");

		// Displaying data that user entered
		echo "<p><u>Here is the info for your account</u><p>";
		echo "First name: <i>" . $_SESSION['firstname'] . "</i><br/>";
		echo "Last name: <i>" . $_SESSION['lastname'] . "</i><br/>";
		echo "Email: <i>" . $_SESSION['email'] . "</i><br/>";
		echo "Username: <i>" . $_SESSION['username'] . "</i><br/>";
		echo "Password: <b>That's a secret only you know...</b><br/>";
	?>

	<p>Please go back to the <a href="index.php">login page</a> and sign in to start texty-ing</p>

</body>
</html>