<!-- JOSEPH BIESELIN - Texty Web App -->
<!DOCTYPE html>
<html>
<head>
	<title>Deactivation of texty account</title>
</head>
<body>

	<!-- Remove user from the system with the associated email and password -->
	<?php
		// Check to make sure inputted user data matches our all_users.txt file

		// Set up variables
		$username = strtolower($_POST['username']);
		$email = strtolower($_POST['email']);
		$password = $_POST['password'];

		// Check if any users were created
		chdir("/var/www/html/files");		
		if(!file_exists("all_users.txt")) {
			echo "We currently have no users. Why don't you <a href='register.html'>register</a> and become one?";
			die();
		}
		// Each line of a file is one index in $file_array
		$file_array = file("all_users.txt");

		$i = 0;
		// Increment through the array
		while($line = $file_array[$i]) {
			$test_user_data = explode(",", $line, 5);
			// Test to see if the inputted username and password match any of the users already in the system
			if(($test_user_data[0] == $username) and ($test_user_data[1] == $email) and ($test_user_data[3] == $password)) {
				// Found a match so we delete the user from the file and call functions to process all other removals
				unset($file_array[$i]); /* remove the instance of the user to be deactivated */
				$all_users_file = fopen("all_users.txt", "w+"); /* truncate the file and write each file array index back to the file, now without the user */
				$file_string = implode($file_array); /* join all array elements and write it back to the file */
				fwrite($all_users_file, $file_string); /* user data is removed from file */
				fclose($all_users_file);

				// Change directory to user's indexed directory and then delete the texty.txt file
				chdir("$test_user_data[2]");
				unlink("texts.txt");

				// Execute function that will remove all traces of the user Hitman style
				// Note: we are in the user's personal directory with followers.txt and followees.txt
				remove_follow_data($test_user_data[2]);

				break;
			}
			$i++; /* increment i */
		}
		if($i == count($file_array)) {
			// fclose($all_users_file);
			// No one matching the inputted data was found in the files
			echo "<script type=\"text/javascript\">alert('Your credentials did not match anyone in our system. You will be redirected back to the deactivation form to input your account information again.'); window.location = \"deactivate.html\";</script>";
		}
		
		// Successfully removed all traces of the user assassin style
		echo "You're always welcome back {$username}<br/><br/>";
		echo "Removed all data...";
	?>

	<!-- Functions for PHP -->
	<?php
		// Note: at the time of execution of these files, we are the directory of user's personal content

		// Removes user from texty.
		// This includes:
		// 		1. Removing the user from the followees.txt file of people who follow the user
		// 		2. Removing the user from the followers.txt file of people who the user follow
		//		3. Deleting the followees.txt & followers.txt file
		//		4. Deleting the directory of the user
		function remove_follow_data($user_index) {

			// 1. Handle removal data of followees.txt (people user follows)
			$followee_file = fopen("followees.txt", "r");
			while($line = fgets($followee_file)) {
				// $followee_array: position 0 = some followee's index, position 1 = some followee's username
				$followee_array = explode(",", $line);
				// The user who is being deactivated is a follower of people in the followees.txt file
				$filepath = "/var/www/html/files/" . $followee_array[0] . "/followers.txt";
				$file_array = file($filepath);
				// Pass the user who is getting removed's index and the followee's file that the user will be removed from
				remove_user($user_index, $file_array, $filepath);
			}
			// 3. Close and delete file
			fclose($followee_file);
			unlink("followees.txt");

			// 2. Handle removal of data of followers.txt (people who follow user)
			$follower_file = fopen("followers.txt", "r");
			while($line = fgets($follower_file)) {
				// $follower_array: position 0 = some follower's index, position 1 = some followers's username
				$follower_array = explode(",", $line);
				// The user who is being deactivated is a followee of people in the followers.txt file
				$filepath = "/var/www/html/files/" . $follower_array[0] . "/followees.txt";
				$file_array = file($filepath);				
				// Pass the user who is getting removed's index and the follower's file that the user will be removed from
				remove_user($user_index, $file_array, $filepath);
			}
			// 3. Close and delete file
			fclose($follower_file);
			unlink("followers.txt");

			// 4. Delete user's directory
			chdir("/var/www/html/files");
			rmdir("$user_index");
		}

		// Find the $user_index in one of $file_array's position and remove that line
		// Then combine the array into a string and write that back to the file
		function remove_user($user_index, $file_array, $filepath) {
			$i = 0;
			while($line = $file_array[$i]) {
				// $user_array: position 0 = some user's index, position = some user's username
				$user_array = explode(",", $line);
				if( $user_array[0] == $user_index) {
					// If we have found the lilne where the user is located, remove user from the file
					unset($file_array[$i]); /* remove current array position where user was located */
					$file = fopen($filepath, "w+"); /* truncate file and write into it without user */
					$file_string = implode($file_array); /* join array back into string */
					fwrite($file, $file_string); /* write string back into file, now with user gone */
					fclose($file);
					break;
				}
				$i++;
			}
		}


	?>

</body>
</html>
