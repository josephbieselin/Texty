/*
	Texty Web App
	Twitter Clone

	Programmer:
	Joseph Bieselin

	Networking code interfaces PHP on user machine with a server running C++ code
	"Database" emulated with C++ file handling
	Threading will be used to handle multiple requests

	
	Structure of all_users.txt:
	N,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'\n'
	username,email,index_i,password,firstname,lastname,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'\n'
	username,email,index_j,password,firstname,lastname,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'\n'
	username,email,index_k,password,firstname,lastname,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'\n'

	... continues on for however many users are in the file;
	Where N is index of the next user (this can go to infinity since numbers are not reused after a user deactivates their account);
	We assume for now that 10 bytes corresponding to the string "999999999" will suffice for 99999999 possible unique user indexes;
	Each line contains strings representing user info separated by commas;
	Each line is 118 bytes where commas are put at the end of each line before the newline character so lines can be overwritten after created


	Structure of followers.txt & followees.txt:
	index_i,username,,,,,,,,,,,,,,,,,,,,,,,,,,'\n'
	index_j,username,,,,,,,,,,,,,,,,,,,,,,,,,,'\n'

	... continues on for however many users are in the file;
	The user that the person is followed by (follower) or the that is following (followee) has their index and username on a line;
	Each line is 28 bytes where commas are put at the end of each line before the newline character so lines can be overwritten after created


	Structure of texts.txt:
	This is a samaple texty from some user'\n'
	This is a second sample from some user'\n'

	The user can input almost any character they want, excluding new lines;
	New lines delimit the end of one texty from the next;
	A texty cannot be deleted... ever, unless the account is deactivated
*/


#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <iostream>
#include <stdio.h>		// perror, snprintf
#include <sys/stat.h>	// provide stat functionality for directory checking
#include <string.h>		// provide c string capabilities
#include <strings.h>	// bzero
#include <unistd.h>		// provide functionality for UNIX calls
#include <dirent.h>		// used for filled in directory entries
#include <stdlib.h>		// malloc, calloc, free
#include <typeinfo>
#include <time.h>        // time, ctime
#include <sys/socket.h>  // socket, AF_INET, SOCK_STREAM,
                         // bind, listen, accept
#include <netinet/in.h>  // servaddr, INADDR_ANY, htons
#include <mutex>
#include <thread>


using namespace std;


/* ---------------------------------- CONSTANTS ----------------------------------------------*/
// File Handling
#define MAX_PATH 1000		// maximum file path is probably not more than 1000 chars
#define USER_DIR "/files"	// directory (relative to CWD) where data on all users for texty will be stored

#define CURRENT_DIR "/var/www/html"	// directory where C++ files and user file directory is stored
#define FILES_DIR "/var/www/html/files"	// directory path for files
#define ALL_USERS_TXT "/var/www/html/files/all_users.txt"	// filepath for the master "all_users.txt" file

#define ALL_USERS_FILE "/all_users.txt"	// corresponds to file with every user's info and index number
#define USER_DATA_FILENAME "all_users.txt"

#define MAX_INDEX_BYTES 10		// maximum number of user indexes that can be used at creation of files: 10 bytes = 999999999 possible indexes for a cstring
#define MAX_USER_INFO_BYTES 118	// maximum number of bytes each line in all_users.txt will be for each user including: user's data, commas, and '\n' character
#define UN_BYTES 17			// maximum number of characters in username based on value limited in PHP file
#define EMAIL_BYTES 41		// maximum number of characters in email based on value limited in PHP file
#define PW_BYTES 17			// maximum number of characters in password based on value limited in PHP file
#define FN_BYTES 21			// maximum number of characters in first name based on value limited in PHP file
#define LN_BYTES 21			// maximum number of characters in last name based on value limited in PHP file
#define GARBAGE_BYTES 70	// length of bytes to hold characters after username and email fields in file handling

#define PHP_MSG_SIZE 130 	// number of characters to hold a message from PHP which could include: 5 chars for function to call, 1 char for a comma, and 118 chars for comma separated user data

#define REGISTER_STR "regst"	// string for registering a user
#define DEACTIVATE_STR "deact"	// string for deactivating a user
#define LOGIN_STR "login"		// string for logging a user in
#define SEARCH_STR "searc"		// string for searching for user
#define DISPLAY_STR "displ"		// string for displaying a user's page
#define OTHER_DISPLAY_STR "ot_ds"	// string for displaying another user's page
#define TEXTY_STR "texty"		// string for a user to send a texty
#define FOLLOW_STR "follo"		// string for a user to follow another user
#define UNFOLLOW_STR "unfol"	// string for a user to unfollow another user
#define LAST_TEXTY_STR "lastT"	// string to get last texty sent by a user

#define COMMA_STR ",";	// a comma is returned when there are errors in function calls

// Networking
#define	MAXLINE		4096	// max text line length
#define	BUFFSIZE	8192    // buffer size for reads and writes
#define  SA struct sockaddr
#define	LISTENQ		1024	// 2nd argument to listen()
#define PORT_NUM    13003
/* ---------------------------------- CONSTANTS ----------------------------------------------*/


mutex PHP_ARGS_MUT;
mutex DIRECTORIES_MUT;


// Global file for the master "all_users.txt" file wrapped in a class
class All_Users {
public:
	mutable mutex mut;
	fstream fh;
	// filename is absolute path of the file
	string filename;

	// Constructor
	All_Users() : filename(ALL_USERS_TXT) {}

	// Copy Constructor and Assignment Operator deleted
	All_Users(const All_Users& copy) = delete;
	All_Users& operator=(const All_Users& right) = delete;

	// Destructor
	~All_Users()
	{
		if (fh.is_open()) {
			cout << "~All_Users --> closing file" << endl;
			fh.close();
		}

	}

	void open_file()
	{
		cout << "All_Users.open_file()" << endl;
		fh.open(filename);
	}

	void close_file()
	{
		cout << "All_Users.close_file()" << endl;
		fh.close();
	}
};
// create a globally accessible variable to handle locking and unlocking of the master "all_users.txt" file
All_Users all_user_file;







// Class for locking user files
class Lock_File {
public:
	mutable mutex mut;
	fstream fh;
	// filename is absolute path of the file
	string filename;

	// Constructor
	Lock_File(const string& index_val, const string& name) : filename(FILES_DIR) {filename += "/" + index_val + "/" + name;}
	
	// Copy Constructor and Assignment Operator deleted
	Lock_File(const Lock_File& copy) = delete;
	Lock_File& operator=(const Lock_File& right) = delete;

	// Destructor
	~Lock_File()
	{
		if (fh.is_open()) {
			cout << "~Lock_file --> closing file" << endl;
			fh.close();
		}
	}

	void open_file()
	{
		cout << "Lock_File.open_file() --> " << filename << endl;
		fh.open(filename);
	}

	void close_file()
	{
		cout << "Lock_File.close_file() --> " << filename << endl;
		fh.close();
	}

	// CANNOT CREATE A FILE TO LOCK A FUNCTION BECAUSE UNIQUE_LOCK & LOCK_GUARD RELEASE LOCKS AT THE END OF FUNCTION CALLS
};
// globally accesible vector that will store the files that are currently locked
vector<Lock_File*> locked_files;



class User_Dir {
public:
	mutable mutex mut;
	string user_index;
	string dir_path;
	Lock_File followees;
	Lock_File followers;
	Lock_File texts;
	Lock_File username;

	// Constructor
	User_Dir(const string& index_val) : user_index(index_val), dir_path(FILES_DIR), followees(index_val, "followees.txt"), followers(index_val, "followers.txt"), texts(index_val, "texts.txt"), username(index_val, "username.txt") { dir_path += "/" + index_val; }

	// Copy Constructor and Assignment Operator deleted
	User_Dir(const User_Dir& copy) = delete;
	User_Dir& operator=(const User_Dir& right) = delete;

	// Destructor
	~User_Dir() {}

	// unset_index is called when a user is being removed from the system; therefore, indicate that the files no longer exist with a "-1" as the directory index
	void unset_index() { user_index = -1; }

	// open files in a user directory
	void open_followees() 
	{
		if (user_index != "-1")
			followees.open_file();
	}

	void open_followers()
	{
		if (user_index != "-1")
			followers.open_file();
	}

	void open_texts()
	{
		if (user_index != "-1")
			texts.open_file();
	}

	string get_username()
	{
		username.open_file();
		string un;
		getline(username.fh, un);
		username.close_file();
		return un;
	}

	// close files in a user directory
	void close_followees()	{ followees.close_file(); }
	void close_followers()	{ followers.close_file(); }
	void close_texts()		{ texts.close_file(); }
};

map<string, User_Dir*> USER_DIRECTORIES;


// // Class for locking user files
// class Lock_Dir {
// public:
// 	mutable mutex mut;
// 	//fstream fh;
// 	// filename is absolute path of the file
// 	string dir_name;

// 	// Constructor
// 	Lock_Dir(const string& index_val) : dir_name(FILES_DIR) {filename += "/" + index_val;}
	
// 	// Copy Constructor and Assignment Operator deleted
// 	Lock_Dir(const Lock_Dir& copy) = delete;
// 	Lock_Dir& operator=(const Lock_Dir& right) = delete;

// 	// Destructor
// 	~Lock_Dir()
// 	{
// 		// if (fh.is_open()) {
// 		// 	cout << "~Lock_file --> closing file" << endl;
// 		// 	fh.close();
// 		// }
// 	}



// 	// void open_file()
// 	// {
// 	// 	cout << "Lock_File.open_file() --> " << filename << endl;
// 	// 	fh.open(filename);
// 	// }

// 	// void close_file()
// 	// {
// 	// 	cout << "Lock_File.close_file() --> " << filename << endl;
// 	// 	fh.close();
// 	// }
// };
// // globally accesible vector that will store the files that are currently locked
// vector<Lock_Dir*> locked_dirs;





// Return true if the passed in cstring is a directory; false otherwise
bool is_dir(const char* path)
{
	struct stat buf;
	int status;
	status = stat(path, &buf);
	if (status == -1) {
		// If stat does not return 0, there was an error
		//cout << endl << "ERROR: is_dir could not check path" << endl;
		return false;
	}

	if ( (buf.st_mode & S_IFDIR) == 0)
		// Directory was not created -- creating "files" directory now
		return false;

	return true; // no errors and path was determined to be a directory
}

// Return true if the passed in cstring is a file that exists; false otherwise
bool file_exists(const char* name)
{
	struct stat buf;
	int status;
	status = stat(name, &buf);
	return status == 0;
}

// Creates the "files" directory and "all_users.txt" file in that directory if they don't already exist (program exits on any errors in their creation)
void create_users_database()
{
	char* my_cwd = (char*) malloc(MAX_PATH);
	char* files_cwd = (char*) malloc(MAX_PATH);
	strcpy(my_cwd, CURRENT_DIR);
	chdir(my_cwd);
	getcwd(my_cwd, MAX_PATH);
	getcwd(files_cwd, MAX_PATH);
	strcat(files_cwd, USER_DIR);

	// create a directory where the user info files will go
	if (!is_dir(files_cwd)) {
		// If the files directory doesn't exist, create it with RWX permissions for everyone
		int status;
		status = mkdir(files_cwd, S_IRWXU|S_IRWXG|S_IRWXO);
		if (status == -1) {
			free(my_cwd); free(files_cwd);
			cout << endl << "ERROR: mkdir could not create files directory" << endl;
			// exit the program if we could not create a directory to store user info
			exit(1);
		}
		chmod(files_cwd, S_IRWXU|S_IRWXG|S_IRWXO); // give everyone RWX permissions
	}
	chdir(files_cwd); // changed into "files" directory where all_users.txt & all user directories are

	// create a file to store all the user's in our system
	char* file_path = (char*) malloc(MAX_PATH);
	strcpy(file_path, files_cwd);
	strcat(file_path, ALL_USERS_FILE);

	if (!file_exists(file_path)) {
		// If the file doesn't exist, create it
		ofstream temp_create_file(file_path);
		temp_create_file.close();
		fstream fh(file_path);
		if (!fh.is_open()) { //.is_open()) {
			cout << endl << "ERROR: could not open all_users.txt" << endl;
			free(my_cwd); free(files_cwd); free(file_path);
			// exit the program if we could not open the file to store all the users in our system
			exit(2);
		} else { // 1st user created will have an index of 1, which changes N to 2 for the next user to register
			// The first line of the file is the index number that the next registered user will receieve, ie: 1 (since the file did not exist yet)
			string index_line = "1";
			for(size_t i = 1; i < MAX_USER_INFO_BYTES - 1; ++i)
				index_line += ",";
			index_line += "\n";
			fh << index_line; // Each line is 118 chars long, with commands appending user data to set a standard line length, and ends with a newline char
			fh.close();
			free(my_cwd); free(files_cwd); free(file_path);
			// string index_1 = "1";
			// // Add this new user's info to the end of the all_users.txt file
			// add_user(fh, un, email, index_1, pw, fn, ln);
			// // Create the new user's directory and followees.txt, followers.txt, texts.txt files
			// create_user_dir("1", dir_buf);
		}
	}

}

// sets up map<string, User_Dir*> USER_DIRECTORIES to contain all files and directories in the system
void create_directory_mappings()
{
	string files_directory = FILES_DIR;
	
	/* Base code taken from StackOverflow URL: http://stackoverflow.com/questions/67273/how-do-you-iterate-through-every-file-directory-recursively-in-standard-c
		Used to read directory entries in the "files" directory which stores created user directories
		These entries are placed into a map structure which is globally available to use
	*/
	char files_path[MAX_PATH + 1];
	strcpy(files_path, files_directory.c_str());
	struct dirent *entry;
	DIR *dp;

	dp = opendir(files_path);
	if (dp == NULL) {
		// error opening directory so exit program
		cout << "ERROR: in create_directory_mappings - could not open directory path for 'files'" << endl;
		exit(1);
	}

	while ((entry = readdir(dp))) {
		// if the directory entry is a directory and not "." or "..", insert it's entry into the USER_DIRECTORIES map
		if ( (entry->d_type == DT_DIR) && ( strcmp(entry->d_name, ".") != 0 ) && ( strcmp(entry->d_name, "..") != 0 ) ) {
			USER_DIRECTORIES.insert(pair<string, User_Dir*> (entry->d_name, new User_Dir(entry->d_name)));
		}
	}
	closedir(dp);
}

// Create 3 .txt files in the passed in directory: followees, followers, texts
void create_user_files(const char* dir, const string& un)
{
	//chdir(dir);
	char user_path[MAX_PATH + 1];

	strcpy(user_path, dir);
	strcat(user_path, "/");
	strcat(user_path, "followees.txt");
	ofstream f1(user_path); f1.close();

	strcpy(user_path, dir);
	strcat(user_path, "/");
	strcat(user_path, "followers.txt");
	ofstream f2(user_path); f2.close();

	strcpy(user_path, dir);
	strcat(user_path, "/");
	strcat(user_path, "texts.txt");
	ofstream f3(user_path); f3.close();

	strcpy(user_path, dir);
	strcat(user_path, "/");
	strcat(user_path, "username.txt");
	ofstream f4(user_path);
	f4 << un;
	f4.close();	
}

/*
A new user needs to be created;
Each user has a directory corresponding to their index number;
Each user's directory has 3 .txt files: followees, followers, texts
*/
void create_user_dir(const char* user_index, const char* dir, const string& un)
{
	//chdir(dir);
	char user_dir[MAX_PATH + 1];
	strcpy(user_dir, FILES_DIR);
	strcat(user_dir, "/");
	strcat(user_dir, user_index);
	int status = mkdir(user_dir, S_IRWXU|S_IRWXG|S_IRWXO);
	if (status == -1) {
		cout << endl << "ERROR: mkdir could not create this new user's directory" << endl;
		return;
	}
	chmod(user_dir, S_IRWXU|S_IRWXG|S_IRWXO); // give everyone RWX permissions
	// char* dir_buf = (char*) malloc(MAX_PATH);
	// strcpy(dir_buf, dir);
	// dir_buf = strcat(dir_buf, "/");
	// dir_buf = strcat(dir_buf, user_index);
	create_user_files(user_dir, un);
	// chdir(dir);
	// free(dir_buf);
	lock_guard<mutex> lk(DIRECTORIES_MUT);
	USER_DIRECTORIES.insert(pair<string, User_Dir*>(user_index, new User_Dir(user_index)));	
}

/*
The parameter check will be used in a switch statement and do one of the following 3 checks
1) If no password is passed, return true if either un or email match the username or email of a user in all_users.txt (used for registering a new user)
2) If a password is passed, return true if both un and pw match one user's username and password (used for logging in)
3) Return true if un, email, and pw all match one user's username, email, and password (used for deactivating a user)
*/
bool user_exists(fstream& fh, int check, const string& un, const string& email, const string& pw = "")
{
	// skip the first of the line of the file because it does not contain user info
	string first_line_garbage;
	fh.clear(); fh.seekp(0, ios::beg); getline(fh, first_line_garbage);

	// test_info is one line from the all_users.txt file
	// test_info = un,email,index,pw,fn,ln

	char* test_un = (char*) malloc(UN_BYTES);
	char* test_email = (char*) malloc(EMAIL_BYTES);
	char* test_index = (char*) malloc(MAX_INDEX_BYTES);
	char* test_pw = (char*) malloc(PW_BYTES);

	char* garbage = (char*) malloc(GARBAGE_BYTES);


	while (!fh.eof()) {
		// Test username
		fh.get(test_un, UN_BYTES, ','); 		// comma separated values, so ',' is the delim parameter

		// ',' is the next character in the stream, so just get that
		fh.get();

		fh.get(test_email, EMAIL_BYTES, ','); 	// comma separated values, so ',' is the delim parameter

		// ',' is the next character in the stream, so just get that
		fh.get();

		// Test index
		fh.get(test_index, MAX_INDEX_BYTES, ',');
		// ',' is the next character in the stream, so just get that
		fh.get();

		fh.get(test_pw, PW_BYTES, ',');			// comma separated values, so ',' is the delim parameter

		// garbage and .get() will get the next ',' along with the rest of the user info that is not need for testing 
		fh.get(); //garbage, 2);
		fh.getline(garbage, GARBAGE_BYTES);

		// 1) test username or email, 2) test username and password, 3) test username, email, and password
		switch (check)
		{
			case 1: // Register: both the username and email should be unique
				if( (strcmp(test_un, un.c_str()) == 0) || (strcmp(test_email, email.c_str()) == 0)  ) {
					free(test_un); free(test_email); free(test_pw); free(garbage);
					return true;
				}
			case 2: // Log in: both the username and password should match
				if( (strcmp(test_un, un.c_str()) == 0) && (strcmp(test_pw, pw.c_str()) == 0) ) {
					free(test_un); free(test_email); free(test_pw); free(garbage);
					return true;
				}
			case 3: // Deactivate: the username, email, and password should match
				if( (strcmp(test_un, un.c_str()) == 0) && (strcmp(test_email, email.c_str()) == 0) && (strcmp(test_pw, pw.c_str()) == 0) ) {
					unique_lock<mutex> lk(DIRECTORIES_MUT);
					unique_lock<mutex> dir_lk(USER_DIRECTORIES[test_index]->mut);
					// for the user that will be soon be removed, set his directory entry index in the global map to "-1" indicating the files are removed
					USER_DIRECTORIES[test_index]->user_index = "-1";
					free(test_un); free(test_email); free(test_pw); free(garbage);
					return true;
				}
		}
	}

	free(test_un); free(test_email); free(test_pw); free(garbage);
	return false; // got to the end of the file so return false
}

// Write over the current line that the fh stream is pointing to with a new index
void write_next_index(fstream& fh, string& next_index)
{
	fh.seekp(0, ios::beg);
	for (size_t i = 0; i < (MAX_USER_INFO_BYTES - next_index.size()); ++i)
		next_index += ",";
	//next_index += "\n";
	fh << next_index;
}

// Takes a file handle and adds the strings of user data to the end of the file with the line structure in the comments at the top
void add_user(fstream& fh, const string& un, const string& email, const string& index_val, const string& pw, const string& fn, const string& ln)
{
	string user_line = un + "," + email + "," + index_val + "," + pw + "," + fn + "," + ln + '\n';
	// Clear any flag bits that may impede writing to the file, then set the stream to point to the end of the file
	fh.clear();
	fh.seekp(0, ios::end);
	fh << user_line;
}

/*
The file passed in will be the followees.txt or followers.txt file containing the user we want to remove;
The index corresponds to the index of the user we will be removing
*/
void remove_user_from_files(fstream& fh, ofstream& temp_file, const string& index_val)
{
	string temp, temp_index;
	while (!fh.eof()) {
		// go through each line getting the index for each user
		getline(fh, temp);
		for (size_t i = 0; i < temp.size(); ++i) {
			if (temp[i] == ',')
				break;
			temp_index += temp[i];
		}

		// if the current line's index is not the user we are removing, add them to the new temp file
		if (temp_index != index_val && temp != "") {
			temp_file << temp;
			temp_file << "\n";
		}

		temp_index.clear();
	}
}

/*
Remove the user from all_users.txt;
Remove the user from the followees.txt file of anyone in the user's followers.txt file;
Remove the user from the followers.txt file of anyone in the user's followees.txt file;
Delete the user's followees.txt, followers.txt, and texts.txt files and the user's directory;
Return the passed inusername if successful
*/
string remove_user(fstream& fh, ofstream& temp_file, const string& un, const char* files_cwd)
{
	string user_index;
	/* ---------------------------- REMOVING USER FROM all_users.txt --------------------------------- */
	string temp, temp_username;
	// place the first line of all_users.txt into the new temp file
	fh.clear(); fh.seekp(0, ios::beg);
	getline(fh, temp);
	temp_file << temp; temp_file << "\n";

	// add all lines of all_users.txt that don't match the specified username into the new temp file
	while (!fh.eof()) {
		getline(fh, temp);
		size_t i;
		for (i = 0; i < temp.size(); ++i) {
			if (temp[i] == ',')
				break;
			temp_username += temp[i];
		}

		// if the current line's user is the not the user we are removing, add them to the new temp file
		if (temp_username != un && temp != "") {
			temp_file << temp;
			temp_file << "\n";
		} else if (temp_username == un) { // this is the user we are removing
			// get user's index
			// first we must parse through the next data value which is the email and i is already at the index of email's first char
			for (++i; i < temp.size(); ++i) {
				if (temp[i] == ',')
					break;
			}
			// get user's index value until the next comma is hit
			for (++i; i < temp.size(); ++i) {
				if (temp[i] == ',')
					break;
				user_index += temp[i];
			}
		}

		temp_username.clear();
	}
	all_user_file.close_file();

	/* ---------- REMOVING USER FROM OTHER PEOPLE'S followers.txt && followees.txt files ------------- */

	// set up variables to change directories, assuming our CWD is where the "files" directory is located
	char* user_dir_cwd = (char*) malloc(MAX_PATH);	// will hold directory of "/files/X" where X is a number representing this user's directory
	char* other_user_dir_cwd = (char*) malloc(MAX_PATH); 	// will hold directory of "/files/Y" where Y is a number representing another user's directory
	
	char* temp_dir = (char*) malloc(MAX_PATH);				// will hold directory of "/files/" as a way to use strcpy to reset other_user_dir_cwd for each new other user's index value
	char temp_filepath[MAX_PATH + 1];							// will hold the file path for another user's followers or followees file

	//chdir(files_cwd);
	
	// Change the current directory to the user's directory who is being removed and set up cstrings to be used
	// getcwd(user_dir_cwd, MAX_PATH);
	// strcat(user_dir_cwd, "/");
	strcpy(user_dir_cwd, FILES_DIR);
	strcat(user_dir_cwd, "/");
	strcat(user_dir_cwd, user_index.c_str());
	strcat(user_dir_cwd, "/");

	// getcwd(other_user_dir_cwd, MAX_PATH);
	// strcat(other_user_dir_cwd, "/");
	strcpy(other_user_dir_cwd, FILES_DIR);
	strcat(other_user_dir_cwd, "/");

	// getcwd(temp_dir, MAX_PATH);
	// strcat(temp_dir, "/");
	strcpy(temp_dir, FILES_DIR);
	strcat(temp_dir, "/");

	//chdir(user_dir_cwd);
	// delete the user's texts.txt file
	unique_lock<mutex> user_text_lk(USER_DIRECTORIES[user_index]->texts.mut);
	remove(USER_DIRECTORIES[user_index]->texts.filename.c_str());
	user_text_lk.unlock();

	unique_lock<mutex> user_un_lk(USER_DIRECTORIES[user_index]->username.mut);
	remove(USER_DIRECTORIES[user_index]->username.filename.c_str());
	user_un_lk.unlock();

	// char users_file[MAX_PATH];
	// strcpy(users_file, user_dir_cwd);
	// strcat(users_file, "texts.txt");
	// remove(users_file);



	// obtain locks on user's files
	unique_lock<mutex> user_followee_lk(USER_DIRECTORIES[user_index]->followees.mut);
	unique_lock<mutex> user_follower_lk(USER_DIRECTORIES[user_index]->followers.mut);
	// open followees file
	USER_DIRECTORIES[user_index]->followees.open_file();

	// set up unique_lock pointer object for other user's
	vector<unique_lock<mutex>*> other_lks;
	unique_lock<mutex>* other_user_file_lk;

	// for each other user in this user's followees.txt file, remove this user from the other user's followers.txt file
	//fstream followees_file("followees.txt");
	string other_user_index;
	while (!USER_DIRECTORIES[user_index]->followees.fh.eof()) {
		// go through each user in the followees.txt file
		getline(USER_DIRECTORIES[user_index]->followees.fh, temp);
		if (temp != "") {
			// get the other user's index value from the followees.txt file
			for (size_t i = 0; i < temp.size(); ++i) {
				if (temp[i] == ',')
					break;
				other_user_index += temp[i];
			}
			// // change to the directory to the other user's directory and open their followers.txt file
			// strcat(other_user_dir_cwd, other_user_index.c_str());
			// chdir(other_user_dir_cwd);
			// fstream other_followers_file("followers.txt");
			//*othher_use_file_lk 


			other_lks.push_back(new unique_lock<mutex> (USER_DIRECTORIES[other_user_index]->followers.mut));


			//other_user_file_lk.lock(USER_DIRECTORIES[other_user_index]->followers.mut);
			USER_DIRECTORIES[other_user_index]->followers.open_file();

			strcpy(temp_filepath, USER_DIRECTORIES[other_user_index]->dir_path.c_str());
			strcat(temp_filepath, "/temp.txt");

			ofstream other_followers_temp_file(temp_filepath);

			// remove the current user from the other user's followers.txt file
			remove_user_from_files(USER_DIRECTORIES[other_user_index]->followers.fh, other_followers_temp_file, user_index);
			
			// remove the old file with the user currently in it, and rename the new temp file to its name
			remove(USER_DIRECTORIES[other_user_index]->followers.filename.c_str());
			rename(temp_filepath, USER_DIRECTORIES[other_user_index]->followers.filename.c_str());

			USER_DIRECTORIES[other_user_index]->followers.close_file();
			other_followers_temp_file.close();

			other_user_index.clear();

			other_user_file_lk = other_lks.back();

			other_user_file_lk->unlock();

			delete other_user_file_lk;

			other_lks.clear();


			// // reset other_user_dir_cwd to be concatenated with the next other user index
			// strcpy(other_user_dir_cwd, temp_dir);
		}
	}

	// close and delete the user's followee file
	USER_DIRECTORIES[user_index]->followees.close_file();
	remove(USER_DIRECTORIES[user_index]->followees.filename.c_str());
	//user_followee_lk.unlock();


	// followees_file.close();
	// chdir(user_dir_cwd);	// change directories back to the current user being removed to get his/her followers.txt file

	// for each other user in this user's followers.txt file, remove this user from the other user's followees.txt file
	// fstream followers_file("followers.txt");

	USER_DIRECTORIES[user_index]->followers.open_file();


	while (!USER_DIRECTORIES[user_index]->followers.fh.eof()) {
		// go through each user in the followers.txt file
		getline(USER_DIRECTORIES[user_index]->followers.fh, temp);
		if (temp != "") {
			// Get the other user's index value from the followers.txt file
			for (size_t j = 0; j < temp.size(); ++j) {
				if( temp[j] == ',')
					break;
				other_user_index += temp[j];
			}
			// change to the directory to the other user's directory and open their followers.txt file
			// strcat(other_user_dir_cwd, other_user_index.c_str());
			// chdir(other_user_dir_cwd);
			// fstream other_followees_file("followees.txt");

			other_lks.push_back(new unique_lock<mutex> (USER_DIRECTORIES[other_user_index]->followees.mut));

			USER_DIRECTORIES[other_user_index]->followees.open_file();

			strcpy(temp_filepath, USER_DIRECTORIES[other_user_index]->dir_path.c_str());
			strcat(temp_filepath, "/temp.txt");

			ofstream other_followees_temp_file(temp_filepath);

			// remove the current user from the other user's followers.txt file
			remove_user_from_files(USER_DIRECTORIES[other_user_index]->followees.fh, other_followees_temp_file, user_index);

			remove(USER_DIRECTORIES[other_user_index]->followees.filename.c_str());
			rename(temp_filepath, USER_DIRECTORIES[other_user_index]->followees.filename.c_str());

			USER_DIRECTORIES[other_user_index]->followees.close_file();
			other_followees_temp_file.close();


			// // remove the old file with the user currently in it, and rename the new temp file to its name
			// remove("followees.txt");
			// rename("temp.txt", "followees.txt");
			// other_followees_file.close(); other_followees_temp_file.close();
			
			other_user_index.clear();

			other_user_file_lk = other_lks.back();

			other_user_file_lk->unlock();
			// reset other_user_dir_cwd to be concatenated with the next other user index
			// strcpy(other_user_dir_cwd, temp_dir);

			delete other_user_file_lk;

			other_lks.clear();

		}
	}

	USER_DIRECTORIES[user_index]->followers.close_file();
	remove(USER_DIRECTORIES[user_index]->followers.filename.c_str());
	//user_follower_lk.unlock();


	// chdir(user_dir_cwd);

	// // For the user being removed, delete his/her files
	// remove("followees.txt");
	// remove("followers.txt");

	// chdir(files_cwd); // setting the working directory back to what it was before the remove_user function was called
	// // For the user being removed, delete his/her directory

	rmdir(USER_DIRECTORIES[user_index]->dir_path.c_str());

	free(user_dir_cwd); free(other_user_dir_cwd); free(temp_dir);

	return un;
}

/*
register takes in 5 strings: first name, last name, email, username, password;
register stores those strings in a CSV line in all_users.txt in the directory files;
if a failure occurs, a comma is returned;
if successful, the string returned is: un,email,fn,ln
*/
string register_user(const string& un, const string& email, const string& pw, const string& fn, const string& ln, char* my_cwd)
{

	//cout << "register " << this_thread::get_id() << endl;


	//chdir(my_cwd); // make sure we are always in the correct directory

	// buf = current working directory; dir_buf = "CWD" + "USER_DIR" (USER_DIR is directory with all users of texty data)
	char* buf = (char*) malloc(MAX_PATH);
	char* dir_buf = (char*) malloc(MAX_PATH);
	getcwd(buf, MAX_PATH);
	strcpy(dir_buf, buf);

	dir_buf = strcpy(dir_buf, FILES_DIR);

	//chdir(dir_buf); // access data inside USER_DIR directory, so change to that directory
	
	// lock the master file to assure no one changes it while we try to register a user
	



	// COMMMENTING THIS OUT
	//unique_lock<mutex> lk(all_user_file.mut);

	// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


	//cout << this_thread::get_id() << " has the lock in register" << endl;


	// open the master file once we've obtained the lock
	all_user_file.open_file();

	char* index_val = (char*) malloc(MAX_INDEX_BYTES); // MAX_INDEX originally set to 1000000 meaning 999999 user indexes could be handled at the creation
	if (!all_user_file.fh.is_open()) {
		free(buf); free(dir_buf); free(index_val);
		cout << endl << "ERROR: could not open all_users.txt" << endl;
		return ",";
	} else { // file is opened	
		all_user_file.fh.getline(index_val, MAX_INDEX_BYTES, ','); // index will get the first line in the file which contains a number followed by the EOL character
		if (user_exists(all_user_file.fh, 1, un, email)) {
			all_user_file.close_file();
			free(buf); free(dir_buf); free(index_val); //free(file_path); free(index);
			cout << endl << "ERROR: username or email already exist --> " << un << " " << email << " " << pw << " " << fn << " " << ln << endl;
			return ",";
		} else {
			// Add this new user's info to the end of the all_users.txt file
			add_user(all_user_file.fh, un, email, index_val, pw, fn, ln);
			// Create the new user's directory and followees.txt, followers.txt, texts.txt files
			create_user_dir(index_val, dir_buf, un);
		}
	}

	// The index at the beginning of all_users.txt must be incremented and updated in the file
	int next_index;
	next_index = atoi(index_val);
	next_index++;
	// Convert the next_index int value into a string to pass to write_next_index
	char next_index_buffer[MAX_INDEX_BYTES];
	sprintf(next_index_buffer, "%d", next_index);
	string next_index_string(next_index_buffer);
	write_next_index(all_user_file.fh, next_index_string); // write_next_index will move the stream to the beginning of the file
	
	all_user_file.close_file();


	//cout << this_thread::get_id() << " giving up the lock in register" << endl;


	//lk.unlock();



	free(index_val);

	


	//chdir(buf); // change the CWD back to its initial position at the beginning of the function
	free(buf); free(dir_buf); //free(file_path);




	// // Check if username or email are taken, if not taken {add this new user's info}
	// char* file_path = (char*) malloc(MAX_PATH);
	// strcpy(file_path, dir_buf);
	// strcat(file_path, ALL_USERS_FILE);

	// fstream fh(file_path);
	// if (!fh.is_open()) {
	// 	free(buf); free(dir_buf); free(file_path);
	// 	cout << endl << "ERROR: could not open all_users.txt" << endl;
	// 	return ",";
	// } else { // file is opened
	// 	char* index = (char*) malloc(MAX_INDEX_BYTES); // MAX_INDEX originally set to 1000000 meaning 999999 user indexes could be handled at the creation
	// 	fh.getline(index, MAX_INDEX_BYTES, ','); // index will get the first line in the file which contains a number followed by the EOL character

	// 	if (user_exists(fh, 1, un, email)) {
	// 		fh.close();
	// 		free(buf); free(dir_buf); free(file_path); free(index);
	// 		cout << endl << "ERROR: username or email already exist" << endl;
	// 		return ",";
	// 	} else { // fh got to EOF in user_exists so user does not exist
	// 		// Add this new user's info to the end of the all_users.txt file
	// 		add_user(fh, un, email, index, pw, fn, ln);
	// 		// Create the new user's directory and followees.txt, followers.txt, texts.txt files
	// 		create_user_dir(index, dir_buf);
	// 	}

	// 	// The index at the beginning of all_users.txt must be incremented and updated in the file
	// 	int next_index;
	// 	next_index = atoi(index);
	// 	next_index++;
	// 	// Convert the next_index int value into a string to pass to write_next_index
	// 	char next_index_buffer[MAX_INDEX_BYTES];
	// 	sprintf(next_index_buffer, "%d", next_index);
	// 	string next_index_string(next_index_buffer);
	// 	write_next_index(fh, next_index_string); // write_next_index will move the stream to the beginning of the file
		
	// 	fh.close();

	// 	free(index);
	// }
	
	// chdir(buf); // change the CWD back to its initial position at the beginning of the function
	// free(buf), free(dir_buf), free(file_path);





	string return_str = un + "," + email + "," + fn + "," + ln;
	return return_str;

	// unique_lock will take care of unlocking the mutex
}

// Takes a username (that is already known to exist) and returns the index of that user
string get_user_index(const string& un)
{
	// string temp, temp_username, user_index;

	//fstream fh(USER_DATA_FILENAME); // open the file with every stored user's info
	//all_user_file.open_file();
	//getline(fh, temp); // index line

	// index is -1 if the username is not associated with any directories
	string the_index = "-1";

	vector<unique_lock<mutex>*> dir_locks;
	unique_lock<mutex>* lk_ptr;

	for (auto& map_index : USER_DIRECTORIES) {
		dir_locks.push_back(new unique_lock<mutex> (map_index.second->mut));
		if (un == map_index.second->get_username())
			the_index = map_index.second->user_index;
		lk_ptr = dir_locks.back();
		lk_ptr->unlock();
		delete lk_ptr;
		dir_locks.clear();
	}

	return the_index;
	// while (!fh.eof()) {
	// 	getline(fh, temp);
	// 	// index is preceded by a username then a ',' then an email then another ','
	// 	size_t i;
	// 	for (i = 0; i < temp.size(); ++i) {
	// 		if (temp[i] == ',')
	// 			break;
	// 		temp_username += temp[i];
	// 	}

	// 	// if the current line's user is the one we're looking for, get the index and return it
	// 	if (temp_username == un) {
	// 		fh.close(); // close the file since we found the index
	// 		// parse through the email chars to get to the index
	// 		for (++i; i < temp.size(); ++i) {
	// 			if (temp[i] == ',')
	// 				break;
	// 		}
	// 		// get the index value and return it
	// 		for (++i; i < temp.size(); ++i) {
	// 			if (temp[i] == ',')
	// 				return user_index;
	// 			user_index += temp[i];
	// 		}
	// 	}

	// 	temp_username.clear(); 
	// }
	// return user_index;
}

// Takes a message and appends it (along with a newline character) to the user's texts.txt file
bool submit_text(const string& texty, const string& un, char* files_cwd)
{
	//chdir(files_cwd); // Change into the files directory
	string user_index = get_user_index(un);
	if (user_index == "-1")
		return false;

	// change into the user's directory and open the texts.txt file
	// char* user_dir = (char*) malloc(MAX_PATH);
	// getcwd(user_dir, MAX_PATH);
	// strcat(user_dir, "/");
	// strcat(user_dir, user_index.c_str());
	// chdir(user_dir);
	// fstream fh("texts.txt");

	unique_lock<mutex> lk(USER_DIRECTORIES[user_index]->texts.mut);
	USER_DIRECTORIES[user_index]->texts.open_file();

	// write the texty to the end of the texts.txt file
	USER_DIRECTORIES[user_index]->texts.fh.seekp(0, ios::end);
	USER_DIRECTORIES[user_index]->texts.fh << texty;
	USER_DIRECTORIES[user_index]->texts.fh << "\n";
	USER_DIRECTORIES[user_index]->texts.close_file();


	// chdir(files_cwd);

	// free (user_dir);

	return true;
}

/*
User (un) wants to follow other user (other_un):
	add the other user's index and username to user's followees.txt file
	add user's index and username to other user's followers.txt file
*/
bool follow_other(const string& un, const string& other_un, char* files_cwd)
{
	//chdir(files_cwd); // Change into the files directory
	string user_index = get_user_index(un);
	string other_user_index = get_user_index(other_un);

	if ( (user_index == "-1") || (other_user_index == "-1") )
		return false;

	
	// // change into the user's directory and open the followees.txt file
	// char* user_dir = (char*) malloc(MAX_PATH);
	// getcwd(user_dir, MAX_PATH);
	// strcat(user_dir, "/");
	// strcat(user_dir, user_index.c_str());
	// chdir(user_dir);
	// fstream user_file("followees.txt");

	unique_lock<mutex> user_lk(USER_DIRECTORIES[user_index]->followees.mut);
	USER_DIRECTORIES[user_index]->followees.open_file();
	// write the other user data to the end of followees.txt
	string other_user_data = other_user_index + "," + other_un + "\n";
	USER_DIRECTORIES[user_index]->followees.fh.seekp(0, ios::end);
	USER_DIRECTORIES[user_index]->followees.fh << other_user_data;
	USER_DIRECTORIES[user_index]->followees.close_file();
	user_lk.unlock();

	// // change into other user's directory and open the followers.txt file
	// chdir(files_cwd);
	// char* other_user_dir = (char*) malloc(MAX_PATH);
	// getcwd(other_user_dir, MAX_PATH);
	// strcat(other_user_dir, "/");
	// strcat(other_user_dir, other_user_index.c_str());
	// chdir(other_user_dir);
	// fstream other_user_file("followers.txt");

	unique_lock<mutex> other_user_lk(USER_DIRECTORIES[other_user_index]->followers.mut);
	USER_DIRECTORIES[other_user_index]->followers.open_file();
	// write the other user data to the end of followers.txt
	string user_data = user_index + "," + un + "\n";
	USER_DIRECTORIES[other_user_index]->followers.fh.seekp(0, ios::end);
	USER_DIRECTORIES[other_user_index]->followers.fh << user_data;
	USER_DIRECTORIES[other_user_index]->followers.close_file();
	other_user_lk.unlock();

	// // write the user data to the end of followers.txt
	// string user_data = user_index + "," + un + "\n";
	// other_user_file.seekp(0, ios::end);
	// other_user_file << user_data;
	// other_user_file.close();

	// chdir(files_cwd);

	// free(user_dir); free(other_user_dir);

	return true;
}

/*
User (un) wants to unfollow other user (other_un):
	remove other user's index and username from user's followees.txt file
	remove user's index and username from other user's followers.txt file
*/
bool unfollow_other(const string& un, const string& other_un, char* files_cwd)
{
	chdir(files_cwd); // Change into the files directory
	string user_index = get_user_index(un);
	string other_user_index = get_user_index(other_un);

	if ( (user_index == "-1") || (other_user_index == "-1") )
		return false;


	// change into the user's directory and open the followees.txt file
	// char* user_dir = (char*) malloc(MAX_PATH);
	// getcwd(user_dir, MAX_PATH);
	// strcat(user_dir, "/");
	// strcat(user_dir, user_index.c_str());
	// chdir(user_dir);
	// // create a temp file to put in all lines of current user's followees.txt except for the line with other_un's data
	// fstream user_file("followees.txt");
	// ofstream temp_file("temp.txt");

	char temp_filename[MAX_PATH + 1];

	strcpy(temp_filename, USER_DIRECTORIES[user_index]->dir_path.c_str());
	strcat(temp_filename, "/temp.txt");

	unique_lock<mutex> user_lk(USER_DIRECTORIES[user_index]->mut);
	unique_lock<mutex> user_file_lk(USER_DIRECTORIES[user_index]->followees.mut);
	USER_DIRECTORIES[user_index]->followees.open_file();
	ofstream temp_file(temp_filename);

	remove_user_from_files(USER_DIRECTORIES[user_index]->followees.fh, temp_file, other_user_index);

	USER_DIRECTORIES[user_index]->followees.close_file();
	temp_file.close();
	remove(USER_DIRECTORIES[user_index]->followees.filename.c_str());
	rename(temp_filename, USER_DIRECTORIES[user_index]->followees.filename.c_str());
	user_lk.unlock();
	user_file_lk.unlock();



	// // change into other user's directory and open the followers.txt file
	// //chdir(files_cwd);
	// char* other_user_dir = (char*) malloc(MAX_PATH);
	// getcwd(other_user_dir, MAX_PATH);
	// strcat(other_user_dir, "/");
	// strcat(other_user_dir, other_user_index.c_str());
	// chdir(other_user_dir);
	// // create another temp file to put in all lines of other user's followers.txt except for the line with un's data
	// fstream other_user_file("followers.txt");
	// ofstream other_temp_file("other_temp.txt");
	// remove_user_from_files(other_user_file, other_temp_file, user_index);
	// other_user_file.close(); other_temp_file.close();
	// remove("followers.txt");
	// rename("other_temp.txt", "followers.txt");

	strcpy(temp_filename, USER_DIRECTORIES[other_user_index]->dir_path.c_str());
	strcat(temp_filename, "/temp.txt");

	unique_lock<mutex> other_user_lk(USER_DIRECTORIES[other_user_index]->mut);
	unique_lock<mutex> other_user_file_lk(USER_DIRECTORIES[other_user_index]->followees.mut);
	USER_DIRECTORIES[other_user_index]->followers.open_file();
	ofstream other_temp_file(temp_filename);

	remove_user_from_files(USER_DIRECTORIES[other_user_index]->followers.fh, other_temp_file, user_index);

	USER_DIRECTORIES[other_user_index]->followers.close_file();
	other_temp_file.close();
	remove(USER_DIRECTORIES[other_user_index]->followers.filename.c_str());
	rename(temp_filename, USER_DIRECTORIES[other_user_index]->followers.filename.c_str());



	// chdir(files_cwd);

	// free(user_dir); free(other_user_dir);

	return true;
}

/*
Updates a string passed by reference to contain all of the data in a user's followees.txt, followers.txt, and texts.txt files
return_string's contents:
	every followee's index and username pair (comma separated): i1,un1,i2,un2,i3,un3,...,i_N,un_N;
	then there will be a newline character;
	every follower's index and username pair (comma separated): same format as followees
	then there will be a newline character;
	every texty the user has sent, each followed by a newline character (newest texty last);
*/
void display_user_page(const string& un, string& return_str, char* files_cwd)
{
	//chdir(files_cwd); // Change into the files directory
	
	string temp_line;
	
	string user_index = get_user_index(un);

	unique_lock<mutex> user_lk(USER_DIRECTORIES[user_index]->mut);

	// // change into the user's directory
	// char* user_dir = (char*) malloc(MAX_PATH);
	// getcwd(user_dir, MAX_PATH);
	// strcat(user_dir, "/");
	// strcat(user_dir, user_index.c_str());
	// chdir(user_dir);

	// // get data in followees.txt
	//fstream followees_file("followees.txt");
	unique_lock<mutex> followee_lk(USER_DIRECTORIES[user_index]->followees.mut);
	USER_DIRECTORIES[user_index]->followees.open_file();

	while (getline(USER_DIRECTORIES[user_index]->followees.fh, temp_line)) {
		return_str += temp_line; return_str += ",";
	}
	USER_DIRECTORIES[user_index]->followees.close_file();
	followee_lk.unlock();

	return_str += "\n"; // end of followees.txt; make newline signify start of followers.txt


	// get data in followers.txt
	//fstream followers_file("followers.txt");
	unique_lock<mutex> follower_lk(USER_DIRECTORIES[user_index]->followers.mut);
	USER_DIRECTORIES[user_index]->followers.open_file();

	while (getline(USER_DIRECTORIES[user_index]->followers.fh, temp_line)) {
		return_str += temp_line; return_str += ",";
	}
	USER_DIRECTORIES[user_index]->followers.close_file();
	follower_lk.unlock();

	return_str += "\n"; // end of followers.txt; make newline signify start of texts.txt

	// get data in texts.txt; put strings a vector because newest texty will be the last line of the file, but it should be the first texty in return_str
	vector<string> textys;

	//fstream texts_file("texts.txt");
	unique_lock<mutex> texts_lk(USER_DIRECTORIES[user_index]->texts.mut);
	USER_DIRECTORIES[user_index]->texts.open_file();

	while (getline(USER_DIRECTORIES[user_index]->texts.fh, temp_line)) {
		textys.push_back(temp_line);
	}
	USER_DIRECTORIES[user_index]->texts.close_file();
	texts_lk.unlock();

	// start from the end of the vector, thus adding the newest texty to return_str first, and the oldest texty last
	for (size_t i = textys.size(); i > 0; --i) {
		return_str += textys[i-1];
		return_str += "\n"; // each texty should be separated by a newline
	}
	
	//free(user_dir);
	
	return;
}

// will return the most recent texty if the user's texts.txt file is opened; '\n' will be returned if it fails or there's no textys
string get_last_texty(const string& un, char* files_cwd)
{
	//chdir(files_cwd); // Change into the files directory
	
	string temp_line;

	string newest_texty = "";
	string user_index = get_user_index(un);
	
	if (user_index == "-1")
		return "\n";
	
	// change into the user's directory
	// char* user_dir = (char*) malloc(MAX_PATH);
	// getcwd(user_dir, MAX_PATH);
	// strcat(user_dir, "/");
	// strcat(user_dir, user_index.c_str());
	// chdir(user_dir);
	
	// char user_text_file[MAX_PATH + 1];
	// strcpy(user_text_file, FILES_DIR);
	// strcat(user_text_file, "/");
	// strcat(user_text_file, user_index.c_str());
	// strcat(user_text_file, "/texts.txt");


	// get last line from texts.txt

	unique_lock<mutex> lk(USER_DIRECTORIES[user_index]->texts.mut);
	USER_DIRECTORIES[user_index]->texts.open_file();
	//fstream texts_file("texts.txt");
	if (!USER_DIRECTORIES[user_index]->texts.fh.is_open()) {
		//free(user_dir);
		return "\n";
	}
	while (getline(USER_DIRECTORIES[user_index]->texts.fh, temp_line)) {
		if (temp_line != "")
			newest_texty = temp_line; // if temp_line holds data, newest_texty will get that data
	}
	// just got to the end of the file because there were no more lines to get
	USER_DIRECTORIES[user_index]->texts.close_file();

	//free(user_dir);
	if (newest_texty == "")
		return "\n";
	return newest_texty; 
}

/*
Search for the username or email of another user:
Return formatted user data in a string if the username/email is found: string = "username,email,index,firstname,lastname"
Return an empty string, "", if the username/email is not found
*/
string search(const string& search_str, char* files_cwd)
{
	// change into the files directory and open the file with all of the users' data
	//chdir(files_cwd);
	//fstream fh(USER_DATA_FILENAME);
	all_user_file.open_file();

	// skip the first of the line of the file because it does not contain user info
	string first_line_garbage;
	getline(all_user_file.fh, first_line_garbage);

	string test_un, test_email, user_data, return_user_data;

	while (!all_user_file.fh.eof()) {
		// get the next line of one user's data
		getline(all_user_file.fh, user_data);
		if (user_data != "") {
			size_t i;
			// get the username to test
			for (i = 0; i < user_data.size(); ++i) {
				if (user_data[i] == ',')
					break;
				test_un += user_data[i];
			}
			// get the email to test
			for (++i; i < user_data.size(); ++i) {
				if (user_data[i] == ',')
					break;
				test_email += user_data[i];
			}

			// if the username or email match, get the first and last name to display also
			if ( (test_un == search_str) || (test_email == search_str) ) {
				all_user_file.close_file(); // close the file since we have all the data needed
				return_user_data = test_un + "," + test_email + ","; // add username and email to string that will be returned
				// get the index and store 
				for (++i; i < user_data.size(); ++i) {
					if (user_data[i] == ',') {
						return_user_data += ",";
						break;
					}
					return_user_data += user_data[i];
				}
				// get the password but don't store it
				for (++i; i < user_data.size(); ++i) {
					if (user_data[i] == ',')
						break;
				}
				// put the rest of the line in return_user_data which already has the username, email, and index stored with comma separation
				for (++i; i < user_data.size(); ++i) {
					return_user_data += user_data[i];
				}

				return return_user_data; // return the formatted user data: username,email,firstname,lastname
			}
		}
		test_un.clear(); test_email.clear();
	}

	all_user_file.close_file();
	//chdir(files_cwd);
	return ","; // return an empty string since no username/email matched
}

/*
Takes a string where the first 5 chars will represent a function that PHP has requested:
	regst = register user;
	deact = deactivate a user's account;
	login = login a user;
	searc = search for a user;
	displ = display the logged in user's home page;
	ot_ds = display other user's page;
Data to be used with this function call will be a string which is passed by referenced as return_str:
	contains comma - "," - if requested action is denied;
	contains requested data if all goes well;
*/
void handle_php_args(const string php_args, char* my_cwd, char* files_cwd, int connfd)
{
	//chdir(my_cwd);

	//cout << "In handle_php_args (args passed): " << php_args << endl;


	// php_args will contain a function to call and necessary user data; data is comma delimited
	string func_to_call = "";
	string un = "";
	string email = "";
	string pw = "";
	string fn = "";
	string ln = "";
		
	string return_str;

	// get all possible values from php_args in order: function,username,email,password,firstname,lastname
	size_t i;
	for (i = 0; i < php_args.size(); ++i) {
		if (php_args[i] == ',')
			break;
		func_to_call += php_args[i];
	}
	for (++i; i < php_args.size(); ++i) {
		if (php_args[i] == ',')
			break;
		un += php_args[i];
	}
	for (++i; i < php_args.size(); ++i) {
		if (php_args[i] == ',')
			break;
		email += php_args[i];
	}
	for (++i; i < php_args.size(); ++i) {
		if (php_args[i] == ',')
			break;
		pw += php_args[i];
	}
	for (++i; i < php_args.size(); ++i) {
		if (php_args[i] == ',')
			break;
		fn += php_args[i];
	}
	for (++i; i < php_args.size(); ++i) {
		if (php_args[i] == ',')
			break;
		ln += php_args[i];
	}


	//cout << "In handle_php_args: " << un << " " << email << " " << pw << " " << fn << " " << ln << endl;

	unique_lock<mutex> lk(all_user_file.mut, defer_lock);

	// functions that do not complete their desired task for whatever reason (bad input, failed calls, etc) return an empty string - ""
	if (func_to_call == REGISTER_STR) {
		lk.lock();
		return_str = register_user(un, email, pw, fn, ln, my_cwd); // returns username,email,firstname,lastname if successful
	}

	else if (func_to_call == DEACTIVATE_STR) {
		// change to the files directory and open all_users.txt
		lk.lock();
		all_user_file.open_file();
		//fstream fh(USER_DATA_FILENAME);
		// if the user doesn't exist, return the empty string
		if (!user_exists(all_user_file.fh, 3, un, email, pw)) {
			all_user_file.close_file();
			//chdir(my_cwd);
			return_str = ",";
		} else {
			// the user exists, so remove them from all_users.txt by creating a temp file without them, then renaming that temp file to all_users.txt
			char temp_filename[MAX_PATH + 1];
			strcpy(temp_filename, FILES_DIR);
			strcat(temp_filename, "/temp.txt");
			//ofstream temp_file("temp.txt");
			ofstream temp_file(temp_filename);
			string remove_str = remove_user(all_user_file.fh, temp_file, un, files_cwd); // returns username if successful
			// remove the old all_users.txt and rename the temp file with updated user info to all_users.txt
			all_user_file.close_file(); temp_file.close();
			remove(all_user_file.filename.c_str());
			rename(temp_filename, all_user_file.filename.c_str());
			//chdir(my_cwd);
			return_str = remove_str;
		}
	}

	else if (func_to_call == LOGIN_STR) {
		// change to the files directory and open all_users.txt
		//chdir(files_cwd);
		lk.lock();
		//fstream fh(USER_DATA_FILENAME);
		all_user_file.open_file();
		if (!user_exists(all_user_file.fh, 2, un, email, pw)) {
			all_user_file.close_file();
			//chdir(my_cwd);
			return_str = ",";
		} else {
			all_user_file.close_file();
			//chdir(my_cwd);
			return_str = un; // returns username
		}
	}

	else if (func_to_call == SEARCH_STR) {
		lk.lock();
		string search_string; // will contain a username or email to search for
		search_string = ( (un != "") ? un : email);
		return_str = search(search_string, files_cwd); // returns username,email,firstname,lastname if user is found
	}

	else if (func_to_call == DISPLAY_STR) {
		string return_string; // will contain all the data from the user's followees, followers, and texts .txt files
		display_user_page(un, return_string, files_cwd); // return_string passed by referenced and changed in the function
		return_str = return_string;
		/*
		return_string's contents:
			every followee's index and username pair (comma separated): i1,un1,i2,un2,i3,un3,...,i_N,un_N;
			then there will be a newline character;
			every follower's index and username pair (comma separated): same format as followees
			then there will be a newline character;
			every texty the user has sent, each followed by a newline character (newest texty first);
		*/
	}

	// do I really need other_display_user?????
	//case OTHER_DISPLAY_STR:

	else if (func_to_call == TEXTY_STR) {
		string the_message = email; // texty gets sent as 3rd value
		if (submit_text(the_message, un, files_cwd)) {
			return_str = un;
		} else {
			return_str = ",";
		}
	}

	else if (func_to_call == LAST_TEXTY_STR) {
		lk.lock();
		return_str = get_last_texty(un, files_cwd);
	}

	else if (func_to_call == FOLLOW_STR) {
		string other_un = email;
		if (follow_other(un, other_un, files_cwd)) {
			return_str = un;
		} else {
			return_str = ",";
		}
	}

	else if (func_to_call == UNFOLLOW_STR) {
		string other_un = email;
		if (unfollow_other(un, other_un, files_cwd)) {
			return_str = un;
		} else {
			return_str = ",";
		}
	}

	else { // if the string does not match somehow, there was an error so return an empty string
		cout << "Error in php_args: function to call was a bad value" << endl;
		return_str = ",";
	}


	// write the message over the network
	unsigned int return_message_size = return_str.size();
	if ( return_message_size != write(connfd, return_str.c_str(), return_str.size()) ) {
		perror("write to connection failed");
	}

	close(connfd);

}



/*
  From Stevens Unix Network Programming, vol 1.
  Minor modifications by John Sterling
 */

int main(int argc, char **argv) {

    int			listenfd, connfd;  // Unix file descriptors
    struct sockaddr_in	servaddr;          // Note C use of struct
    //char		buff[MAXLINE];
    //time_t		ticks;

    // 1. Create the socket
    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("Unable to create a socket");
        exit(1);
    }

    // 2. Set up the sockaddr_in

    // zero it.  
    // bzero(&servaddr, sizeof(servaddr)); // Note bzero is "deprecated".  Sigh.
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family      = AF_INET; // Specify the family
    // use any network card present
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port        = htons(PORT_NUM);	// daytime server

    // 3. "Bind" that address object to our listening file descriptor
    if (bind(listenfd, (SA *) &servaddr, sizeof(servaddr)) == -1) {
        perror("Unable to bind port");
        exit(2);
    }

    // 4. Tell the system that we are going to use this sockect for
    //    listening and request a queue length
    if (listen(listenfd, LISTENQ) == -1) {
        perror("Unable to listen");
        exit(3);
    }
    
    // initialize directories, files and mapping data for the simulated database
    create_users_database();
    create_directory_mappings();

    vector<thread> threads;

    unique_lock<mutex> lk(PHP_ARGS_MUT, defer_lock);

    for ( ; ; ) {
        // 5. Block until someone connects.
        //    We could provide a sockaddr if we wanted to know details of whom
        //    we are talking to.
        //    Last arg is where to put the size of the sockaddr if
        //    we asked for one
		fprintf(stderr, "Ready to connect.\n");
	        if ((connfd = accept(listenfd, (SA *) NULL, NULL)) == -1) {
	            perror("accept failed");
	            exit(4);
		}
		fprintf(stderr, "Connected\n");

        // We had a connection.  Do whatever our task is.
        // ticks = time(NULL);
        // snprintf(buff, sizeof(buff), "%.24s\r\n", ctime(&ticks));

		/* ---------------------------- HANDLING MESSAGE PASSING OVER NETWORK -------------------------------------*/
		char php_args[PHP_MSG_SIZE + 1];	// first 5 bytes will be the function to call in C++; remaining message will be passed in user info
		int read_bytes = read(connfd, php_args, PHP_MSG_SIZE); // number of bytes read from connection file descriptor
		if (read_bytes == PHP_MSG_SIZE) {
			// change into the directory where files are stored
			char* my_cwd = (char*) malloc(MAX_PATH);
			char* files_cwd = (char*) malloc(MAX_PATH);
			// strcpy(my_cwd, CURRENT_DIR);
			// chdir(my_cwd);
			// getcwd(my_cwd, MAX_PATH);
			// getcwd(files_cwd, MAX_PATH);
			// strcat(files_cwd, USER_DIR);
			// chdir(files_cwd); // changed into "files" directory where all_users.txt & all user directories are
			// everything passed in will be separated by commas
			// handle_php_args will perform necessary C++ functions based on PHP's message passed
			


			//string message_to_return = handle_php_args(php_args, my_cwd, files_cwd, connfd);
			lk.lock();
			threads.push_back( thread( [php_args, my_cwd, files_cwd, connfd] { handle_php_args(php_args, my_cwd, files_cwd, connfd); } ) );
			lk.unlock();

			// change back into original directory
			//chdir(my_cwd);
			// get the return message's size to confirm the correct number of bytes are written to the file stream
			//unsigned int return_message_size = message_to_return.size();
			// there is an error if the entire contents of the message was not passed
			// if ( return_message_size != write(connfd, message_to_return.c_str(), message_to_return.size()) ) {
			// 	perror("write to connection failed");
			// }
		} else { // the connection did not read as many bytes as was passed
			perror("read from connection failed");
		}


        // 6. Close the connection with the current client and go back
        //    for another.
        //close(connfd);
    }

    // join the threads so they run to completion
    for (auto& t : threads)
    	t.join();

}




















/* Some tester code I was using

    vector<thread> threads;

    char php_args[PHP_MSG_SIZE + 1];
	string m1, m2, m3, m4, m5, m6, m7;
	// append a new thread to the threads vector and join it so that it finishes execution

	unique_lock<mutex> lk(PHP_ARGS_MUT, defer_lock);


	lk.lock();
	strcpy(php_args, "searc,lexA,ml@gmail.com,password1,mitch,lee,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
	//string args = php_args;
	threads.push_back( thread( [php_args, my_cwd, files_cwd, &m1] { handle_php_args(php_args, my_cwd, files_cwd, m1); } ) );
	lk.unlock();

	lk.lock();
	strcpy(php_args, "follo,lork,lexA,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
	//args = php_args;
	threads.push_back( thread( [php_args, my_cwd, files_cwd, &m2] { handle_php_args(php_args, my_cwd, files_cwd, m2); } ) );
	lk.unlock();

	lk.lock();
	strcpy(php_args, "follo,lork,joebee,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
	//args = php_args;
	threads.push_back( thread( [php_args, my_cwd, files_cwd, &m3] { handle_php_args(php_args, my_cwd, files_cwd, m3); } ) );
	lk.unlock();

	lk.lock();
	strcpy(php_args, "deact,doge,dog@verizon.net,password1,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
	//args = php_args;
	threads.push_back( thread( [php_args, my_cwd, files_cwd, &m4] { handle_php_args(php_args, my_cwd, files_cwd, m4); } ) );
	lk.unlock();

	lk.lock();
	strcpy(php_args, "texty,lexA,my first texty in 4e,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
	//args = php_args;
	threads.push_back( thread( [php_args, my_cwd, files_cwd, &m5] { handle_php_args(php_args, my_cwd, files_cwd, m5); } ) );
	lk.unlock();

	lk.lock();
	strcpy(php_args, "follo,lexA,joebee,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
	//args = php_args;
	threads.push_back( thread( [php_args, my_cwd, files_cwd, &m6] { handle_php_args(php_args, my_cwd, files_cwd, m6); } ) );
	lk.unlock();

	lk.lock();
	strcpy(php_args, "displ,joebee,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
	//args = php_args;
	threads.push_back( thread( [php_args, my_cwd, files_cwd, &m7] { handle_php_args(php_args, my_cwd, files_cwd, m7); } ) );
	lk.unlock();



	//handle_php_args(php_args, my_cwd, files_cwd, message_to_return);
	for (auto& t : threads) t.join();

	cout << "message 1: " << m1 << endl; // 
	cout << "message 2: " << m2 << endl; // 
	cout << "message 3: " << m3 << endl; // 
	cout << "message 4: " << m4 << endl; // 
	cout << "message 5: " << m5 << endl; // 
	cout << "message 6: " << m6 << endl; // 
	cout << "message 7: " << m7 << endl << endl; // 

	for (auto& i : USER_DIRECTORIES) {
		cout << "key: " << i.first << " - index: " << i.second->user_index << " - dir_path: " << i.second->dir_path << ", files: " << i.second->followees.filename << " " << i.second->followers.filename << " " << i.second->texts.filename << endl << endl;
	}


	//chdir(my_cwd);
	// get the return message's size to confirm the correct number of bytes are written to the file stream
	//unsigned int return_message_size = message_to_return.size();




}
*/